// Copyright Epic Games, Inc. All Rights Reserved.

#include "ShootingGroundsGameMode.h"

AShootingGroundsGameMode::AShootingGroundsGameMode()
{
	// stub
}
